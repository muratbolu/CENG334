#include "eshell.hpp"

int main()
{
    eshell{};
    return 0;
}
